package co.kr.jsj.test2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import co.kr.jsj.nfc.NFC;
import co.kr.jsj.nfc.TagDispatch;

public class PayActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pay);
		
		Button tMoneyBtn = (Button)findViewById(R.id.tMoneyBtn);
		tMoneyBtn.setOnClickListener(
			new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					Intent intent = new Intent(getBaseContext(), NFC.class);
					startActivity(intent);
				}
			}
		);
	}
}
